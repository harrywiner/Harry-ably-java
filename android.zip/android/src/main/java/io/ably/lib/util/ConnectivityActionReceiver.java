package io.ably.lib.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import io.ably.lib.transport.ConnectionManager;

public class ConnectivityActionReceiver extends BroadcastReceiver {

    public ConnectivityActionReceiver()
    {}

    public void onReceive(Context context, Intent intent){

        boolean isConnected = intent.getBooleanExtra(ConnectivityManager.EXTRA_NO_CONNECTIVITY, false);

        if (isConnected)
        { AndroidNetworkConnectivity.getInstance().notifyNetworkAvailable(); }
        else
        { AndroidNetworkConnectivity.getInstance().notifyNetworkUnavailable(ConnectionManager.REASON_DISCONNECTED); }
    }


}

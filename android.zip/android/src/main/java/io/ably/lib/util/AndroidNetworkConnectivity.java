package io.ably.lib.util;

import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import io.ably.lib.types.ErrorInfo;

import java.util.HashSet;
import java.util.Set;

public class AndroidNetworkConnectivity extends NetworkConnectivity {
    public static AndroidNetworkConnectivity getInstance() { return instance; }
    private static final AndroidNetworkConnectivity instance = new AndroidNetworkConnectivity();

    private Context context;
    void setContext(Context context)
    {
        if (this.context == null)
        {
            this.context = context;
            IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
            context.registerReceiver(new ConnectivityActionReceiver(), filter);

        }
    }

    public Context getContext()
    { return context; }

}
